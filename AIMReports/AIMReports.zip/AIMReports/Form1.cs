using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.Data.OleDb;
using System.Configuration;
using System.IO;
using System.Collections;
using System.Windows.Forms;


namespace AIMS.EWS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            
            {
                OpenDBConnection();
                CaseLastCommentSLA = System.Configuration.ConfigurationSettings.AppSettings["CaseLastCommentSLA"];

                if ((DateTime.Now.DayOfWeek > DayOfWeek.Sunday | DateTime.Now.DayOfWeek < DayOfWeek.Saturday) & (DateTime.Now.Hour == 18 && DateTime.Now.ToString("tt") == "PM")){
                    GenerateFilesCourierGreaterThan100K();
                    GenerateFilesNOTCourierGreaterThan100K();
                    GenerateFilesWithoutCommentsinLast24HoursPerGuarantor();
                    GenerateFilesPendedForTenDays();
                    GenerateFilesWithoutMedicalCommentsinLast24Hours();
                }

                if ((DateTime.Now.DayOfWeek > DayOfWeek.Sunday | DateTime.Now.DayOfWeek < DayOfWeek.Saturday) & (DateTime.Now.Hour == 16 && DateTime.Now.ToString("tt") == "PM")){
                    GenerateFilesNotTaggedToOperators();
                }

                if ((DateTime.Now.DayOfWeek > DayOfWeek.Sunday | DateTime.Now.DayOfWeek < DayOfWeek.Saturday) & (DateTime.Now.Hour == 7 && DateTime.Now.ToString("tt") == "AM"))
                {
                    GenerateAfterHoursFiles();
                    GenerateWorkBaskets();
                    ProcessPendedCase();
                }

                if (DateTime.Now.Hour == 7 && DateTime.Now.ToString("tt") == "AM")
                {
                    GenerateFilesForPatientsDischargedInLast24Hours();
                }

                // Administration Productivity
                if ((DateTime.Now.DayOfWeek == DayOfWeek.Monday) & (DateTime.Now.Hour == 7 && DateTime.Now.ToString("tt") == "AM"))
                {
                    GenerateAdminProductivity();
                    //GenerateFilesAdmittedNOTDischargedAfter14Days();
                    GenerateFilesCancelled7DaysAgo();
                    GenerateFilesCourierAfterDischarge();
                    GenerateFilesCourierAfterDischargeLateLog();
                    GenerateFilesPendedWithFutureAdmissionDate();
                }
                
                //GenerateFilesTaggedToOperators();
                //GenerateFilesTaggedToOperatorsWithoutMedicalComments();
                //GenerateFilesWithoutCommentsinLast24Hours();
                
               CloseDBConnections();
            }
            finally
            {
                Application.ExitThread();
            }
        }
        #region "Local Declarations"
        public OleDbConnection oleDBConnection;
        public OleDbCommand oleDBCmd;
        string CaseLastCommentSLA = "2";
        #endregion

        #region "Database Methods"
        public bool OpenDBConnection()
        {
            bool DBConnected = false;
            try
            {
                string DBConnectString = System.Configuration.ConfigurationSettings.AppSettings["ConnectString"];

                oleDBConnection = new OleDbConnection();
                oleDBConnection.ConnectionString = DBConnectString;
                oleDBConnection.Open();
                DBConnected = true;
            }
            catch (System.Exception ex)
            {
                LogMessages(ex.ToString(), "AIMS Utility Stop Error", true);
                if (oleDBConnection != null && oleDBConnection.State == ConnectionState.Open)
                {
                    DBConnected = true;
                }
                else
                {
                    DBConnected = false;
                }
            }
            return DBConnected;
        }

        public void CloseDBConnections()
        {
            try
            {
                if (oleDBConnection != null && oleDBConnection.State == ConnectionState.Open)
                {
                    oleDBConnection.Close();
                    oleDBConnection.Dispose();
                }
            }
            catch (System.Exception ex)
            {
                LogMessages(ex.ToString(), "Closing Database Connections", true);
            }
        }
        #endregion

        #region "Error Logging Methods"
        protected void LogMessages(string ErrorLog, string ErrorSource, bool ErrorNote)
        {
            try
            {
                string LogFileName = @"C:\AIMS Recorder\AIMSUtility - " + System.DateTime.Now.ToString("ddMMMyyyy") + ".log";
                StreamWriter strWriter = new StreamWriter(LogFileName);

                if (ErrorNote)
                {
                    strWriter.WriteLine("AIMS Utility Error Report");
                    strWriter.WriteLine("AIMS Utility Error Source: " + ErrorSource);
                    strWriter.WriteLine("AIMS Utility Error : " + ErrorLog);
                }
                else
                {
                    strWriter.WriteLine("AIMS Utility Progress Report");
                    strWriter.WriteLine("AIMS Utility Status : " + ErrorLog);
                }

                strWriter.Flush();
                strWriter.Close();
                strWriter.Dispose();
            }
            finally
            {
            }
        }
        #endregion

        #region "Polling Timer"
        private void AIMSTimer_Tick(object sender, EventArgs e)
        {

        }

        private void AIMSTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            this.LogMessages("Service Running", "", false);
        }
        #endregion

        #region "Processing Functions"
        public void AIMSReports()
        {
            try
            {
                bool DBConnect = OpenDBConnection();
                if (DBConnect)
                {
                    string SQLString = "";

                }
                else
                {
                }
            }
            catch (System.Exception ex)
            {
                throw;
            }
        }

        public void ProcessPendedCase() 
        {
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string PatientID = "";
            string CoOrdinator = "";
            string SQLString = "";

            try
            {
                SQLString = "select a.PEND_DATE, b.MODIFIED_USER, a.FILE_OPERATOR_TO_USERID ," +
                   " datediff (d,CONVERT (smalldatetime, a.pend_date, 103), getdate ()),a.PATIENT_ID, a.PATIENT_FILE_NO  from AIMS_PATIENT a, AIMS_A_PATIENT b " +
                   " where a.PEND_DATE is not null and a.PEND_DATE <> '' and " +
                   " datediff (d,CONVERT (smalldatetime, a.pend_date, 103), getdate ()) > 10 and " +
                   " b.PATIENT_ID = a.PATIENT_ID and " +
                   " b.AUDIT_ID = (Select MAX(AUDIT_ID) from AIMS_A_PATIENT c " +
                   " where c.PATIENT_ID = b.PATIENT_ID and  " +
                   " c.PEND_DATE is not null and c.PEND_DATE <> '') "+
                   " order by 2";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["PATIENT_FILE_NO"].ToString();
                        PatientID = dtDrillReportData.Rows[i]["PATIENT_ID"].ToString();

                        CoOrdinator = dtDrillReportData.Rows[i]["FILE_OPERATOR_TO_USERID"].ToString();
                        if (CoOrdinator == "")
                        {
                            CoOrdinator = dtDrillReportData.Rows[i]["MODIFIED_USER"].ToString();
                        }
                        
                        SQLString = "Update AIMS_PATIENT SET PEND_DATE = NULL, FILE_OPERATOR_TO_USERID = '" + CoOrdinator  + "' where PATIENT_ID = " + PatientID;

                        cmdDrillReport.CommandText = SQLString;
                        cmdDrillReport.CommandType = CommandType.Text;
                        cmdDrillReport.ExecuteNonQuery();

                        SQLString = "insert into AIMS_EWS_INSTANT_MESSAGING " +
                        " values (GETDATE(),'Pend-Date Expired on your Pended Case', '" + CoOrdinator + "','SYSTEM'," + PatientID + ") ";

                        cmdDrillReport.CommandText = SQLString;
                        cmdDrillReport.CommandType = CommandType.Text;
                        cmdDrillReport.ExecuteNonQuery();

                        SQLString = "insert into AIMS_NOTES " +
                        " values ('SYSTEM', 'Case automatically unpended - Pend Date Expired.', getdate(), " + PatientID  + ", 7) ";

                        cmdDrillReport.CommandText = SQLString;
                        cmdDrillReport.CommandType = CommandType.Text;
                        cmdDrillReport.ExecuteNonQuery();   
                    }
                }
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
            }
        }
        public bool GenerateAndEmailReport()
        {
            bool ReportGenerated = false;
            bool blResult = false;
            string sEmailBody = "";
            string SQLString = "";
            string ReportDesc = "";
            string ReportStoredProc = "";
            DateTime ReportLastExecDate;
            string ReportsFields = "";
            OleDbCommand cmdReports = new OleDbCommand();
            OleDbDataReader rdrReports;
            string ReportProcType = "";
            DataTable dtReportsData = new DataTable();
            OleDbDataAdapter oleDBAdaptor;

            OleDbCommand cmdReportExec = new OleDbCommand();
            try
            {
                AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();
                SQLString = "Select * from AIMS_REPORTS";

                cmdReportExec.Connection = oleDBConnection;
                cmdReports.Connection = oleDBConnection;
                cmdReports.CommandText = SQLString;
                rdrReports = cmdReports.ExecuteReader();
                while (rdrReports.Read())
                {
                    ReportDesc = rdrReports["REPORT_DESC"].ToString();
                    ReportStoredProc = rdrReports["REPORT_PROC_NAME"].ToString();
                    ReportLastExecDate = System.Convert.ToDateTime(rdrReports["REPORT_LAST_RUN_DTTM"]);
                    ReportsFields = rdrReports["REPORT_FIELDS_DEFINITION"].ToString();
                    ReportProcType = rdrReports["REPORT_PROC_TYPE"].ToString();

                    if (ReportStoredProc.Trim() != "")
                    {
                        cmdReportExec.CommandText = ReportStoredProc;
                        switch (ReportProcType)
                        {
                            case "SQL":
                                cmdReportExec.CommandType = CommandType.Text;
                                break;
                            case "PROC":
                                cmdReportExec.CommandType = CommandType.StoredProcedure;
                                break;
                        }
                        cmdReportExec.ExecuteReader();
                        oleDBAdaptor = new OleDbDataAdapter(cmdReportExec);
                        oleDBAdaptor.Fill(dtReportsData);
                        if (dtReportsData.Rows.Count > 0)
                        {
                            Int32 iDtRowCnt = 0;
                            bool AddReportHeader = true;
                            for (int i = 0; i < dtReportsData.Rows.Count; i++)
                            {
                                foreach (DataRow dtRow in dtReportsData.Rows)
                                {
                                    if (ReportsFields.Contains(dtRow[iDtRowCnt].ToString()))
                                    {
                                        if (AddReportHeader)
                                        {
                                            AddReportHeader = false;
                                        }
                                    }
                                    iDtRowCnt++;
                                }
                            }
                        }
                    }

                }

                //blResult = aimsEmailer.SendEmailNotify(sEmailBody);
                if (blResult)
                {

                }
                else
                {
                    LogMessages("Report Emailing Problem", "AIMS Emailing Utility", true);
                }
            }
            catch (Exception)
            {
                throw;
            }

            return ReportGenerated;
        }
        
        public bool GenerateBUReports()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sMainReportEmailBody = "";
            string sEmailBody = "";
            bool blResult = false;

            // Main Report Variables
            OleDbCommand cmdReport = new OleDbCommand();
            DataTable dtReportData = new DataTable();
            OleDbDataAdapter oleDBAdaptor;
            string GuarantorID = "";
            string FileConsolidationTotal = "";
            decimal AllGuarantorsTotal = 0;
            string GuarantorName = "";
            string MainReportEmailSubject = "Guarantors Consolidations Total Summary Report";

            // Drill down report variables
            OleDbCommand cmdDrillReport = new OleDbCommand();
            DataTable dtDrillReportData = new DataTable();
            OleDbDataAdapter oleDrillDBAdaptor;
            string PatientFileNo = "";
            string PatientLastName = "";
            string PatientCreationDTTM = "";
            string PatientConsolidationTotal = "";
            string DrillReportEmailSubject = "Guarantors Patients Consolidations Total Summary Report";

            try
            {
                sMainReportEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=4>" +
                                "<center><font color=5CACEE face=calibri size=4><b>AIMS Guarantor Consolidations Summary</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=4>&nbsp;</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=4>&nbsp;</td>" +
                                "</tr>" +
                                "<td bgcolor=lightgrey valign=bottom colspan=4><b>Guarantors Consolidations Total</b></td>" +
                                "</tr>";

                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=4>" +
                                "<center><font color=5CACEE face=calibri size=4><b>AIMS Guarantors Consolidations</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=4>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT guarantor_name Guarantor_Name, " +
                                     " COUNT (aims_patient.patient_id) Active_Patient_Files, " +
                                     " SUM(CAST (ai1.invoice_amount_received AS money)) INVOICE_AMOUNT_RECEIVED, aims_guarantor.guarantor_id " +
                                " FROM aims_guarantor LEFT OUTER JOIN aims_patient " +
                                     " ON aims_patient.guarantor_id = aims_guarantor.guarantor_id " +
                                     " LEFT OUTER JOIN aims_invoice ai1 " +
                                     " ON aims_patient.patient_id = ai1.patient_id " +
                               " WHERE aims_guarantor.guarantor_id NOT IN (58, 57) " +
                            " GROUP BY guarantor_name, aims_guarantor.guarantor_id " +
                              " HAVING COUNT (INVOICE_AMOUNT_RECEIVED) > 0 " +
                            " ORDER BY 1 ";

                cmdReport.Connection = oleDBConnection;
                cmdReport.CommandText = SQLString;
                oleDBAdaptor = new OleDbDataAdapter(cmdReport);
                oleDBAdaptor.Fill(dtReportData);
                if (dtReportData.Rows.Count > 0)
                {
                    for (int i = 0; i < dtReportData.Rows.Count; i++)
                    {
                        GuarantorID = dtReportData.Rows[i]["guarantor_id"].ToString();
                        FileConsolidationTotal = dtReportData.Rows[i]["INVOICE_AMOUNT_RECEIVED"].ToString();
                        AllGuarantorsTotal += System.Convert.ToDecimal(FileConsolidationTotal);
                        GuarantorName = dtReportData.Rows[i]["Guarantor_Name"].ToString();

                        sEmailBody += "<tr>" +
                                        "<td align=left bgcolor=lightgrey colspan=2><center><b><font color=green size=2 >" + GuarantorName + "</font></b></center></td>" +
                                        "<td align=right bgcolor=lightgrey colspan=4>" +
                                        "<b><font color=red size=2><b>" + FileConsolidationTotal + "</b></font></b>" +
                                        "</td>" +
                                        "</tr>";

                        sMainReportEmailBody += "<tr>" +
                                                "<td  colspan=2 bgcolor=#ffffff width=50% style=TEXT-TRANSFORM: capitalize>" + GuarantorName + "</td>" +
                                                "<td colspan=2 bgcolor=#efefef width=50% align=left><font size=2 color=green><b>" + System.Convert.ToDecimal(FileConsolidationTotal).ToString("C") + "</b></font></td> " +
                                                "</tr>" +
                                                "<tr>" +
                                                "<td colspan=4 align=left bgcolor=lightgrey>" +
                                                "<center><b><font color=green size=2 >&nbsp;</font></b></center>" +
                                                "</td>" +
                                                "</tr>";


                        SQLString = "SELECT  top 30 aims_patient.CREATION_DTTM, aims_patient.patient_file_no, aims_patient.patient_last_name, " +
                                             " SUM(CAST (ai1.invoice_amount_received AS money)) invoice_amount_received " +
                                        " FROM aims_guarantor LEFT OUTER JOIN aims_patient " +
                                             " ON aims_patient.guarantor_id = aims_guarantor.guarantor_id " +
                                             " LEFT OUTER JOIN aims_invoice ai1 " +
                                             " ON aims_patient.patient_id = ai1.patient_id " +
                                      " WHERE aims_guarantor.guarantor_id = " + GuarantorID + "" +
                                    " GROUP BY aims_patient.patient_file_no, " +
                                             " patient_last_name, " +
                                             " aims_guarantor.guarantor_name, " +
                                             " aims_patient.CREATION_DTTM " +
                                      " HAVING COUNT (ai1.invoice_amount_received) > 0 " +
                                    " ORDER BY 2 DESC ";

                        cmdDrillReport.Connection = oleDBConnection;
                        cmdDrillReport.CommandText = SQLString;
                        cmdDrillReport.CommandType = CommandType.Text;
                        oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                        oleDrillDBAdaptor.Fill(dtDrillReportData);
                        if (dtDrillReportData.Rows.Count > 0)
                        {
                            sEmailBody += "<tr>" +
                                       "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                                       "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Last name</b></td>" +
                                       "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File Creation Date</b></td>" +
                                       "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Consolidations Total</b></td>" +
                                        "</tr>";
                            for (int j = 0; j < dtDrillReportData.Rows.Count; j++)
                            {
                                PatientFileNo = dtDrillReportData.Rows[j]["PATIENT_FILE_NO"].ToString();
                                PatientLastName = dtDrillReportData.Rows[j]["PATIENT_LAST_NAME"].ToString();
                                PatientCreationDTTM = System.Convert.ToDateTime(dtDrillReportData.Rows[j]["CREATION_DTTM"]).ToShortDateString().ToString();
                                PatientConsolidationTotal = dtDrillReportData.Rows[j]["INVOICE_AMOUNT_RECEIVED"].ToString();
                                sEmailBody += "<tr>" +
                               "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                               "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientLastName + "</td>" +
                               "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientCreationDTTM + "</td>" +
                               "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + System.Convert.ToDecimal(PatientConsolidationTotal).ToString("C") + "</td>" +
                               "</tr>";
                            }

                            sEmailBody += "<tr>" +
                            "<td colspan=4 align=left bgcolor=lightgrey>" +
                            "<center><b><font color=green size=2 >&nbsp;</font></b></center>" +
                            "</td>" +
                            "</tr>";
                        }
                    }
                }

                sEmailBody += "</table>" +
                "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                string LogFileName = @"C:\AIMS Guarantors Report.html";
                StreamWriter strWriter = new StreamWriter(LogFileName);
                strWriter.WriteLine(sEmailBody);
                strWriter.Flush();
                strWriter.Close();
                strWriter.Dispose();

                sMainReportEmailBody += "<tr>" +
                    "<td colspan=2 bgcolor=#ffffff width=50% style=TEXT-TRANSFORM: capitalize align=right><b>TOTAL</b></td>" +
                    "<td colspan=2 bgcolor=#efefef width=50% align=left><font size=2 color=green><b>" + AllGuarantorsTotal.ToString("C") + "</b></font></td>" +
                    "</tr>" +
                    "</table>" +
                    "<br>" +
                    "<br>" +
                    "</body>" +
                    "</html>";

                blResult = aimsEmailer.SendEmailNotify(sMainReportEmailBody, MainReportEmailSubject, "");

                if (blResult)
                {
                    LogMessages("AIMS Guarantors Summary Report Email sent successfully", "Email Successful", false);
                    blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "");
                    if (!blResult)
                    {
                        LogMessages("AIMS Guarantors Full Report Email NOT sent successfully", "Email UnSuccessful", true);
                    }
                    else
                    {
                        LogMessages("AIMS Guarantors Full Report Email sent successfully", "Email Successful", false);
                    }
                }
                else
                {
                    LogMessages("AIMS Guarantors Summary Report Email NOT sent successfully", "Email UnSuccessful", true);
                }
            }
            catch (System.Exception ex)
            {
                LogMessages(ex.ToString(), "Generate Guarantors Summary Report", true);
            }
            finally
            {
                aimsEmailer = null;
                cmdDrillReport.Dispose();
            }
            return true;
        }

        public void GenerateFilesCourierAfterDischargeLateLog()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string PatientName = "";
            string AdmissionDate = "";
            string Discharge_Date = "";
            string SLAViolationDays = "";
            string LateLogYN = "";
            string LateLogDTTm = "";
            string Hospital = "";

            string DrillReportEmailSubject = "Files Not Couriered After 10 Days Of Patient Discharge Date - Late Log Cases";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=5>" +
                                "<center><font color=5CACEE face=calibri size=4><b>Files Not Couriered After 10 Days Of Patient Discharge Date - Late Log Cases</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=5>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT patient_file_no Patient_File_No, " +
                                       " patient_admission_date Admission_Date, " +
                                       " patient_discharge_date Discharge_Date, " +
                                       " a.LATE_LOG_YN, a.LATE_LOG_DATE ," +
                                       " datediff (D, CONVERT (smalldatetime, patient_discharge_date, 103), getdate()) File_Not_Couriered, " +
                                       " LTRIM(dbo.initcap(b.TITLE_DESC) + ' ' + dbo.initcap(PATIENT_FIRST_NAME ) +' ' + dbo.initcap(patient_last_name)) patient_name," +
                                       " d.guarantor_name SUPPLIER_NAME " +
                                  " FROM aims_patient a, AIMS_TITLE b, aims_supplier c, aims_guarantor d " +
                                 " WHERE  a.patient_file_no not like '10%' and a.CANCELLED = 'N' and a.patient_discharge_date IS NOT NULL and a.patient_discharge_date <> '' " +
                                   " AND (a.file_courier_date IS NULL OR a.file_courier_date = '')" +
                                   " AND datediff (D, CONVERT (smalldatetime, patient_discharge_date, 103), getdate()) > 10 " +
                                   " AND b.TITLE_ID = a.TITLE_ID and c.supplier_id = a.supplier_id and d.guarantor_id = a.guarantor_id AND LATE_LOG_YN = 'Y' ORDER BY cast(substring(a.PATIENT_FILE_NO,1,2) as numeric)";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Full Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Discharge Date</b></td>" +
                               //"<td bgcolor=lightgrey valign=bottom align=center><b>Guarantor</b></td>" +
                               //"<td bgcolor=lightgrey valign=bottom align=center><b>Late Log Y/N</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Late Log Date</b></td>" +
                               //"<td bgcolor=lightgrey valign=bottom aligns=center><b>SLA Violation Days</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["Patient_File_No"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["Admission_Date"].ToString();
                        Discharge_Date = dtDrillReportData.Rows[i]["Discharge_Date"].ToString();
                        SLAViolationDays = dtDrillReportData.Rows[i]["File_Not_Couriered"].ToString();
                        Hospital = dtDrillReportData.Rows[i]["SUPPLIER_NAME"].ToString();
                        LateLogYN = dtDrillReportData.Rows[i]["LATE_LOG_YN"].ToString();
                        LateLogDTTm = dtDrillReportData.Rows[i]["LATE_LOG_DATE"].ToString();

                        if (!LateLogDTTm.Equals(""))
                        {
                            LateLogDTTm = System.Convert.ToDateTime(LateLogDTTm).ToShortDateString();
                        }
                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Discharge_Date + "</td>" +
                        //"<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Hospital + "</td>" +
                        //"<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + LateLogYN + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + LateLogDTTm + "</td>" +
                        //"<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + SLAViolationDays + "</td>" +
                        "</tr>";
                    }

                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><b>" + DrillReportEmailSubject + "</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "debbie@aims.org.za;DominicB@aims.org.za");
                if (blResult)
                {
                    LogMessages(DrillReportEmailSubject + " Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages(DrillReportEmailSubject + " Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), DrillReportEmailSubject , true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesCourierAfterDischarge()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string PatientName = "";
            string AdmissionDate = "";
            string Discharge_Date = "";
            string SLAViolationDays = "";
            string LateLogYN = "";
            string LateLogDTTm = "";
            string Hospital = "";

            string DrillReportEmailSubject = "Files Not Couriered After 10 Days Of Patient Discharge Date";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=8>" +
                                "<center><font color=5CACEE face=calibri size=4><b>Files Not Couriered After 10 Days Of Patient Discharge Date</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=8>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT patient_file_no Patient_File_No, " +
                                       " patient_admission_date Admission_Date, " +
                                       " patient_discharge_date Discharge_Date, " +
                                       " a.LATE_LOG_YN, a.LATE_LOG_DATE ," +
                                       " datediff (D, CONVERT (smalldatetime, patient_discharge_date, 103), getdate()) File_Not_Couriered, " +
                                       " LTRIM(dbo.initcap(b.TITLE_DESC) + ' ' + dbo.initcap(PATIENT_FIRST_NAME ) +' ' + dbo.initcap(patient_last_name)) patient_name," +
                                       " d.guarantor_name SUPPLIER_NAME " +
                                  " FROM aims_patient a, AIMS_TITLE b, aims_supplier c, aims_guarantor d " +
                                 " WHERE  a.patient_file_no not like '10%' and a.CANCELLED = 'N' and a.patient_discharge_date IS NOT NULL and a.patient_discharge_date <> '' " +
                                   " AND (a.file_courier_date IS NULL OR a.file_courier_date = '')" +
                                   " AND datediff (D, CONVERT (smalldatetime, patient_discharge_date, 103), getdate()) > 10 " +
                                   " AND b.TITLE_ID = a.TITLE_ID and c.supplier_id = a.supplier_id and d.guarantor_id = a.guarantor_id and LATE_LOG_YN = 'N' ORDER BY d.guarantor_name, cast(substring(a.PATIENT_FILE_NO,1,2) as numeric)";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Full Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Discharge Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Guarantor</b></td>" +
                               //"<td bgcolor=lightgrey valign=bottom align=center><b>Late Log Y/N</b></td>" +
                               //"<td bgcolor=lightgrey valign=bottom align=center><b>Late Log Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom aligns=center><b>SLA Violation Days</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["Patient_File_No"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["Admission_Date"].ToString();
                        Discharge_Date = dtDrillReportData.Rows[i]["Discharge_Date"].ToString();
                        SLAViolationDays = dtDrillReportData.Rows[i]["File_Not_Couriered"].ToString();
                        Hospital = dtDrillReportData.Rows[i]["SUPPLIER_NAME"].ToString();
                        //LateLogYN = dtDrillReportData.Rows[i]["LATE_LOG_YN"].ToString();
                        //LateLogDTTm = dtDrillReportData.Rows[i]["LATE_LOG_DATE"].ToString();
                        
                        //if (!LateLogDTTm.Equals(""))
                        //{
                        //    LateLogDTTm = System.Convert.ToDateTime(LateLogDTTm).ToShortDateString();
                        //}
                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Discharge_Date + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Hospital + "</td>" +
                        //"<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + LateLogYN + "</td>" +
                        //"<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + LateLogDTTm + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + SLAViolationDays + "</td>" +
                        "</tr>";
                    }

                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=8><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=8><b>All Files For Patients Discharged In The Last 10 days have been couried.</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "debbie@aims.org.za; DominicB@aims.org.za");
                if (blResult)
                {
                    LogMessages("Files Not Couriered Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages("Files Not Couriered Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Files Not Couried after 10 days of Discharge Date", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesCancelled7DaysAgo()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string AdmissionDate = "";
            string PatientName = "";
            string Guarantor = "";
            string Datecancelled = "";
            string CancelledBy = "";

            string DrillReportEmailSubject = "Patients Files cancelled in the last 7 days";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=5>" +
                                "<center><font color=5CACEE face=calibri size=4><b>Patients Files cancelled in the last 7 days</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=5>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT   " +
                            " a.patient_file_no, " +
                            " LTRIM (  dbo.INITCAP (e.title_desc) " +
                            " + ' ' " +
                            " + dbo.INITCAP (a.patient_first_name) " +
                            " + ' ' " +
                            " + dbo.INITCAP (a.patient_last_name) " +
                            " ) patient_name, " +
                            " c.guarantor_name, d.MODIFIED_DATE DATE_CANCELLED, f.User_Full_Name " +
                            " FROM aims_patient a, aims_title e, aims_guarantor c, aims_a_patient d, AIMS_USERS f " +
                            " WHERE a.cancelled = 'Y' " +
                            " AND e.title_id = a.title_id " +
                            " AND c.guarantor_id = a.guarantor_id " +
                            " AND d.patient_id = a.patient_id " +
                            " AND d.audit_id = " +
                            " (SELECT MIN (e.audit_id) " +
                            " FROM aims_a_patient e " +
                            " WHERE e.patient_id = a.patient_id AND e.cancelled = 'Y') " +
                            " and f.User_Name = d.MODIFIED_USER " +
                            " and  datediff (D,  d.MODIFIED_DATE, getdate()) <= 7 " +
                            " ORDER BY 1,CAST (substring (a.patient_file_no, 1, 2) AS NUMERIC), " +
                            " CAST (RTRIM (substring (a.patient_file_no, 4, 5)) AS NUMERIC) ";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Full Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Guarantor</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Date Cancelled</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>File Cancelled By</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["PATIENT_FILE_NO"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        Guarantor = dtDrillReportData.Rows[i]["guarantor_name"].ToString();
                        Datecancelled = dtDrillReportData.Rows[i]["DATE_CANCELLED"].ToString();
                        CancelledBy = dtDrillReportData.Rows[i]["User_Full_Name"].ToString();

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Guarantor + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Datecancelled + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + CancelledBy + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><b>NO PATIENT FILES CANCELLED IN THE LAST 7 DAYS</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages("Patients Files cancelled in the last 7 days", "Email Successful", false);
                }
                else
                {
                    LogMessages("Patients Files cancelled in the last 7 days", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Patients Admitted NOT discharged after 14 Days", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesForPatientsDischargedInLast24Hours()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string DrillReportEmailSubject = "Patient File Discharged - Last 24 Hours [" + DateTime.Now.AddDays(-1).ToShortDateString() + "]";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=5>" +
                                "<center><font color=5CACEE face=calibri size=4><b>"+ DrillReportEmailSubject +"</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=5>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT patient_file_no, patient_last_name, b.user_full_name, " +
                             " a.patient_discharge_date, c.GUARANTOR_NAME " +
                             " FROM aims_patient a, aims_users b, AIMS_GUARANTOR c " +
                             " WHERE patient_discharge_date IS NOT NULL and patient_discharge_date <> '' and a.CANCELLED = 'N' " +
                             " AND datediff (d,CONVERT (datetime, patient_discharge_date, 103), getdate ()) = 1 " +
                             " AND b.user_name = a.file_operator_to_userid " +
                             " and c.GUARANTOR_ID = a.GUARANTOR_ID " +
                             " order by user_full_name, PATIENT_FILE_NO ";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Co-Ordinator</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Last Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Guarantor</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Date Discharged</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + dtDrillReportData.Rows[i]["user_full_name"].ToString() +"</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + dtDrillReportData.Rows[i]["patient_file_no"].ToString() + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + dtDrillReportData.Rows[i]["patient_last_name"].ToString() + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + dtDrillReportData.Rows[i]["GUARANTOR_NAME"].ToString() + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + dtDrillReportData.Rows[i]["patient_discharge_date"].ToString() + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><b>NO PATIENT FILES DISCHARGED IN LAST 24 HOURS</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages("Patients Files Discharged in 24 Hours", "Email Successful", false);
                }
                else
                {
                    LogMessages("Patients Files Discharged in 24 Hours", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Patients Files Discharged in 24 Hours ERROR", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesPendedWithFutureAdmissionDate()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string AdmissionDate = "";
            string PatientName = "";
            string SLAViolationDays = "";
            string LateLogDTTm = "";
            string LateLogYN = "";
            string InOutPatient = "";
            string GuarantorName = "";

            string DrillReportEmailSubject = "Patient Cases - Impending Status";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=5>" +
                                "<center><font color=5CACEE face=calibri size=4><b>" + DrillReportEmailSubject + "</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=5>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT patient_file_no, " +
                            " LTRIM (  dbo.INITCAP (c.title_desc) "+
                            " + ' ' "+
                            " + dbo.INITCAP (patient_first_name) "+
                            " + ' ' "+
                            " + dbo.INITCAP (patient_last_name) "+
                            " ) patient_name, "+
                            " patient_admission_date, b.guarantor_name, a.in_patient, a.out_patient "+
                            " FROM aims_patient a, aims_guarantor b, aims_title c "+
                            " WHERE a.CANCELLED = 'N' AND a.pending = 'Y' " +
                            " AND a.patient_admission_date IS NOT NULL "+
                            " AND CONVERT (smalldatetime, a.patient_admission_date, 103) > getdate () "+
                            " AND b.guarantor_id = a.guarantor_id "+
                            " AND c.title_id = a.title_id";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=10%><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=30%><b>Patient Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=10%><b>Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=25%><b>Guarantor</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=10%><b>Type Of Case</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["PATIENT_FILE_NO"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["PATIENT_NAME"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["patient_admission_date"].ToString();
                        GuarantorName = dtDrillReportData.Rows[i]["guarantor_name"].ToString();
                        
                        InOutPatient = dtDrillReportData.Rows[i]["OUT_PATIENT"].ToString();

                        if (InOutPatient.Equals("Y"))
                        {
                            InOutPatient = "<b>OUT-Patient</b>";
                        }
                        else
                        {
                            InOutPatient = "<b>IN-Patient</b>";
                        }

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + GuarantorName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + InOutPatient + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";

                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><b>" + DrillReportEmailSubject + " - Records Up-to-date</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages(DrillReportEmailSubject + " sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages(DrillReportEmailSubject + " Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating " +DrillReportEmailSubject, true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }
        public void GenerateFilesAdmittedNOTDischargedAfter14Days()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string AdmissionDate = "";
            string PatientName = "";
            string SLAViolationDays = "";
            string LateLogDTTm = "";
            string LateLogYN = "";
            string InOutPatient = "";
            string InPatient = "";

            string DrillReportEmailSubject = "Patients Admitted NOT discharged after 14 Days";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=6>" +
                                "<center><font color=5CACEE face=calibri size=4><b>Patients Admitted NOT discharged after 14 days</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=6>&nbsp;</td>" +
                                "</tr>";

                SQLString = "select  a.PATIENT_FILE_NO, a.PATIENT_ADMISSION_DATE, " +
                                " LTRIM( dbo.initcap(e.TITLE_DESC) + ' ' + dbo.initcap(PATIENT_FIRST_NAME ) +' ' + dbo.initcap(patient_last_name)) patient_name, " +
                                " a.LATE_LOG_YN, a.LATE_LOG_DATE, a.OUT_PATIENT, a.IN_PATIENT  " +
                                " from AIMS_PATIENT a, AIMS_TITLE e " +
                                " where " +
                                "  a.CANCELLED = 'N' and (a.pending = 'N' or a.pending is null) and " +
                                " (a.PATIENT_ADMISSION_DATE IS NOT NULL or PATIENT_ADMISSION_DATE <> '') " +
                                " and" +
                                " datediff (D, CONVERT (smalldatetime, a.PATIENT_ADMISSION_DATE, 103), getdate()) > 14 and " +
                                " (a.PATIENT_DISCHARGE_DATE is null or a.PATIENT_DISCHARGE_DATE = '') and " +
                                " e.TITLE_ID = a.TITLE_ID " +
                                " order by cast(substring(a.PATIENT_FILE_NO,1,2) as numeric) ";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=5%><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=5%><b>Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=40%><b>Patient Full Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=5%><b>Late Log(Y/N)</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=5%><b>Late Log Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=5%><b>Patient Status</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["PATIENT_FILE_NO"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["PATIENT_ADMISSION_DATE"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        LateLogYN = dtDrillReportData.Rows[i]["LATE_LOG_YN"].ToString();
                        LateLogDTTm = dtDrillReportData.Rows[i]["LATE_LOG_DATE"].ToString();
                        InOutPatient = dtDrillReportData.Rows[i]["OUT_PATIENT"].ToString();
                        InPatient = dtDrillReportData.Rows[i]["IN_PATIENT"].ToString();

                        if (!LateLogDTTm.Equals(""))
                        {
                            LateLogDTTm = System.Convert.ToDateTime(LateLogDTTm).ToShortDateString();
                        }
                        if (InOutPatient.Equals("Y"))
                        {
                            InOutPatient = "<b>OUT-Patient</b>";
                        }
                        else if (InPatient.Equals("Y"))
                        {
                            InOutPatient = "<b>IN-Patient</b>";
                        }
                        else
                        {
                            InOutPatient = "";
                        }

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + LateLogYN + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + LateLogDTTm + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + InOutPatient + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=6><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";

                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=6><b>Patients Admitted NOT discharged after 14 Days NOT FOUND - Records Up-to-date</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages("Patients Admitted NOT discharged after 14 Days Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages("Patients Admitted NOT discharged after 14 Days Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Patients Admitted NOT discharged after 14 Days", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesCourierGreaterThan100K()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string PatientName = "";
            string AdmissionDate = "";

            string DischargeDate = "";
            string Supplier_Name = "";
            string FileConsolidationAmt = "";
            string FileCourierDate = "";
            decimal totalConsolidation = 0;

            string DrillReportEmailSubject = "Consolidation File Greater Than 100K Couriered (Last 10 Days)";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=7>" +
                                "<center><font color=5CACEE face=calibri size=4><b>Consolidation File Greater Than 100K Couriered (Last 10 Days)</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=7>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT patient_file_no patient_file_no, " +
                                    " a.PATIENT_ADMISSION_DATE, " +
                                    " a.PATIENT_DISCHARGE_DATE, " +
                                    " (a.PATIENT_LAST_NAME + ' ' + a.PATIENT_FIRST_NAME) PATIENT_NAME, " +
                                     " dbo.INITCAP (c.supplier_name) supplier_name, " +
                                     " sum(cast(d.INVOICE_AMOUNT_RECEIVED as money)) CONSOLIDATION_AMOUNT, " +
                                     " a.FILE_COURIER_DATE " +
                                " FROM aims_patient a, aims_title b, aims_supplier c, AIMS_INVOICE d " +
                               " WHERE a.CANCELLED = 'N' and a.patient_discharge_date IS NOT NULL " +
                                 " AND (a.file_courier_date IS NOT NULL ) " +
                                 " AND b.title_id = a.title_id " +
                                 " AND c.supplier_id = a.supplier_id " +
                                 " AND d.PATIENT_ID = a.PATIENT_ID " +
                                 " AND datediff (D, CONVERT (smalldatetime, a.FILE_COURIER_DATE, 103), getdate()) <= 10 " +
                                 " group by patient_file_no,  a.PATIENT_LAST_NAME, a.PATIENT_FIRST_NAME, supplier_name, FILE_COURIER_DATE, PATIENT_ADMISSION_DATE, PATIENT_DISCHARGE_DATE " +
                                  " having  sum(cast(d.INVOICE_AMOUNT_RECEIVED as money )) > CAST('100000' as money ) " +
                            " ORDER BY cast(substring(a.PATIENT_FILE_NO,1,2) as numeric) ";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Discharge Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Supplier/Hospital</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom aligns=center><b>File Courier Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Consolidation Amount</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["patient_file_no"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["PATIENT_ADMISSION_DATE"].ToString();
                        DischargeDate = dtDrillReportData.Rows[i]["PATIENT_DISCHARGE_DATE"].ToString();
                        Supplier_Name = dtDrillReportData.Rows[i]["supplier_name"].ToString();
                        FileConsolidationAmt = System.Convert.ToDecimal(dtDrillReportData.Rows[i]["CONSOLIDATION_AMOUNT"].ToString()).ToString("C");
                        totalConsolidation += System.Convert.ToDecimal(dtDrillReportData.Rows[i]["CONSOLIDATION_AMOUNT"].ToString());
                        FileCourierDate = System.Convert.ToDateTime(dtDrillReportData.Rows[i]["FILE_COURIER_DATE"].ToString()).ToShortDateString();
                        PatientName = dtDrillReportData.Rows[i]["PATIENT_NAME"].ToString();

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + DischargeDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Supplier_Name + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + FileCourierDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + FileConsolidationAmt + "</td>" +
                        "</tr>";
                    }

                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=right colspan=7><font color=red><b>Total Amount : " + totalConsolidation.ToString("C") + "</b></font></td>" +
                                "</tr>";
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=7><font color=red><b>Consolidation Files Count: " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=7><b>NO Consolidation File Greater Than 100K Couried.</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "debbie@aims.org.za");
                if (blResult)
                {
                    LogMessages("Files Not Couriered Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages("Files Not Couriered Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Files Not Couried after 10 days of Discharge Date", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesNOTCourierGreaterThan100K()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string PatientName = "";
            string AdmissionDate = "";
            string DischargeDate = "";
            string Supplier_Name = "";
            string FileConsolidationAmt = "";
            decimal totalConsolidation = 0;

            string DrillReportEmailSubject = "Consolidation File Greater Than 100K NOT Couriered";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=6>" +
                                "<center><font color=5CACEE face=calibri size=4><b>Consolidation File Greater Than 100K NOT Couriered</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=6>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT patient_file_no patient_file_no,   " +
                                    " a.PATIENT_ADMISSION_DATE, " +
                                    " a.PATIENT_DISCHARGE_DATE, " +
                                     " (a.PATIENT_LAST_NAME + ' ' + a.PATIENT_FIRST_NAME) PATIENT_NAME, " +
                                     " dbo.INITCAP (c.supplier_name) supplier_name, " +
                                     " sum(cast(d.INVOICE_AMOUNT_RECEIVED as money)) CONSOLIDATION_AMOUNT " +
                                " FROM aims_patient a, aims_title b, aims_supplier c, AIMS_INVOICE d " +
                               " WHERE a.CANCELLED = 'N' and a.patient_discharge_date IS NOT NULL " +
                                 " AND (a.file_courier_date IS NULL or a.file_courier_date = '') " +
                                 " AND b.title_id = a.title_id " +
                                 " AND c.supplier_id = a.supplier_id " +
                                 " AND d.PATIENT_ID = a.PATIENT_ID " +
                                 " group by patient_file_no, supplier_name,PATIENT_LAST_NAME, PATIENT_FIRST_NAME ,PATIENT_ADMISSION_DATE, PATIENT_DISCHARGE_DATE " +
                                  " having  sum(cast(d.INVOICE_AMOUNT_RECEIVED as money )) > CAST('100000' as money ) " +
                            " ORDER BY cast(substring(a.PATIENT_FILE_NO,1,2) as numeric) ";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Discharge Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Supplier/Hospital</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Consolidation Amount</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["patient_file_no"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["PATIENT_NAME"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["PATIENT_ADMISSION_DATE"].ToString();
                        DischargeDate = dtDrillReportData.Rows[i]["PATIENT_DISCHARGE_DATE"].ToString();
                        Supplier_Name = dtDrillReportData.Rows[i]["supplier_name"].ToString();
                        FileConsolidationAmt = System.Convert.ToDecimal(dtDrillReportData.Rows[i]["CONSOLIDATION_AMOUNT"].ToString()).ToString("C");
                        totalConsolidation += System.Convert.ToDecimal(dtDrillReportData.Rows[i]["CONSOLIDATION_AMOUNT"].ToString());


                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + DischargeDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Supplier_Name + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + FileConsolidationAmt + "</td>" +
                        "</tr>";
                    }

                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=right colspan=6><font color=red><b>Total Amount : " + totalConsolidation.ToString("C") + "</b></font></td>" +
                                "</tr>";
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=6><font color=red><b>Consolidation Files Count: " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=6><b>NO Consolidation File Greater Than 100K NOT Couried.</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "debbie@aims.org.za;reinette@aims.org.za");
                if (blResult)
                {
                    LogMessages("Files Not Couriered Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages("Files Not Couriered Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Files Not Couried after 10 days of Discharge Date", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesPendedForTenDays()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string AdmissionDate = "";
            string PatientName = "";
            string PatientFilePendDate = "";
            string SLAViolationDays = "";
            string DrillReportEmailSubject = "Patient File Pended For Over 2 Days";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=4>" +
                                "<center><font color=5CACEE face=calibri size=4><b>Patient File Pended For Over 2 Days</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=4>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT a.patient_file_no, a.patient_admission_date, " +
                " LTRIM (  dbo.INITCAP (e.title_desc) " +
                " + ' ' " +
                " + dbo.INITCAP (patient_first_name) " +
                " + ' ' " +
                " + dbo.INITCAP (patient_last_name) " +
                " ) patient_name, " +
                " pend_date " +
                " FROM aims_patient a, aims_title e " +
                " WHERE a.cancelled = 'N' " +
                " AND a.pend_date IS NOT NULL " +
                " AND datediff (d, CONVERT (smalldatetime, a.pend_date, 103), getdate ()) >= 2 " +
                " AND e.title_id = a.title_id order by cast(substring(a.PATIENT_FILE_NO,1,2) as numeric)";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Full Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File Pend Date</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["PATIENT_FILE_NO"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["PATIENT_ADMISSION_DATE"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        PatientFilePendDate = dtDrillReportData.Rows[i]["pend_date"].ToString();

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFilePendDate + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=4><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";

                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=4><b>Patients Files Pended For Days Over 2 NOT FOUND - Records Up-to-date</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages("Patients Files Pended For Days Over 2 Days Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages("Patients Files Pended For Days Over 2 Days Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Patients Files Pended For Days Over 2 Days ", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesTaggedToOperators()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string AdmissionDate = "";
            string PatientName = "";
            string FileAllocatedTo = "";
            string DischargeDate = "";
            string LastNoteCaptured = "";
            string NotesDateTime = "";
            string GuarantorName = "";
            

            string DrillReportEmailSubject = "Files Tagged to Operations Team - With Last Comment";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table  cellpadding=1 cellspacing=1 border=1 bordercolor=black width=100% align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=8>" +
                                "<center><font color=5CACEE face=calibri size=4><b>Files Tagged to Operations Team - With Last Comment</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=8>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT " +
                           " d.User_Full_Name FILE_ALLOCATED_TO, " +
                            " a.patient_file_no, " +
                            " dbo.INITCAP (a.patient_last_name + ' ' + a.patient_first_name) patient_name, " +
                            " c.guarantor_name,  " +
                            " a.patient_admission_date, " +
                            " a.patient_discharge_date, " +
                            " RTRIM (LTRIM (b.notes)) LAST_NOTE_CAPTURED,  " +
                            " b.notes_dttm " +
                            " FROM aims_patient a, aims_notes b, aims_guarantor c, AIMS_USERS d " +
                            " WHERE a.CANCELLED = 'N'  and (a.pending = 'N' or a.pending is null) AND file_operator_to_userid IS NOT NULL " +
                            " AND (A.PATIENT_DISCHARGE_DATE IS null OR A.PATIENT_DISCHARGE_DATE = '') " +
                            " AND b.patient_id = a.patient_id " +
                            " AND b.note_id = (SELECT MAX (note_id) FROM aims_notes WHERE aims_notes.patient_id = a.patient_id) " +
                            " AND c.guarantor_id = a.guarantor_id " +
                            " and d.User_Name = file_operator_to_userid " +
                            " ORDER BY file_operator_to_userid, CAST (substring (a.patient_file_no, 1, 2) AS NUMERIC)";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Co-Ordinator</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Patient Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Guarantor</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Admission Date</b></td>" +
                               //"<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Discharge Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=left nowrap><b>Last Note/Comment Captured</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Note/Comment Date Time</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        FileAllocatedTo = dtDrillReportData.Rows[i]["FILE_ALLOCATED_TO"].ToString();
                        PatientFileNo = dtDrillReportData.Rows[i]["PATIENT_FILE_NO"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["PATIENT_NAME"].ToString();
                        GuarantorName = dtDrillReportData.Rows[i]["GUARANTOR_NAME"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["PATIENT_ADMISSION_DATE"].ToString();
                        DischargeDate = dtDrillReportData.Rows[i]["PATIENT_DISCHARGE_DATE"].ToString();
                        LastNoteCaptured = dtDrillReportData.Rows[i]["LAST_NOTE_CAPTURED"].ToString();
                        NotesDateTime = dtDrillReportData.Rows[i]["NOTES_DTTM"].ToString();

                        if (DischargeDate == "") { DischargeDate = "<font color=white>-</font>"; }
                        if (LastNoteCaptured == "") { LastNoteCaptured = "<font color=white>-</font>"; }
                        if (AdmissionDate == "") { AdmissionDate = "<font color=white>-</font>"; }
                        if (PatientName == "") { PatientName = "<font color=white>-</font>"; }

                        sEmailBody += "<tr style=border-style:thick>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + FileAllocatedTo + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + PatientFileNo + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + PatientName + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + GuarantorName + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + AdmissionDate + "</td>" +
                        //"<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + DischargeDate + "</td>" +
                        "<td valign=top bgcolor=#ffffff align=center><b>" + LastNoteCaptured.Replace("\r\n", "<br>") + "</b></td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + NotesDateTime + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=8><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";

                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=8><b>Files Tagged to Operations Team - With Last Comment - Records Up-to-date</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages("Patients Admitted NOT discharged after 14 Days Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages("Patients Admitted NOT discharged after 14 Days Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Patients Admitted NOT discharged after 14 Days", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesWithoutCommentsinLast24Hours()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor; 
            DataTable dtDrillReportData = new DataTable();

            string AdmissionDate = "";
            string PatientName = "";
            string Guarantor = "";

            string caseManager ="";
            string PatientFile ="";
            string NotesDTTM ="";
            string CommentSLAViolation = "";

            string DrillReportEmailSubject = "Patient Files Without Updated Notes/Comment in "+ System.Convert.ToInt64(CaseLastCommentSLA)*24 +" Hours";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=7>" +
                                "<center><font color=5CACEE face=calibri size=4><b>" + DrillReportEmailSubject  + "</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=7>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT   d.user_full_name file_allocated_to, a.patient_file_no, " +        
                                             " dbo.INITCAP (a.patient_last_name + ' ' + a.patient_first_name " +        
                                                         " ) patient_name, " +        
                                             " c.guarantor_name, a.patient_admission_date, " +    
                                             " RTRIM (LTRIM (b.notes)) last_note_captured, b.notes_dttm, " +  
                                             " datediff (D, CONVERT (smalldatetime, b.notes_dttm, 103), getdate()) COMMENT_SLA " +         
                                        " FROM aims_patient a, aims_notes b, aims_guarantor c, aims_users d " +        
                                       " WHERE " +
                                       " CANCELLED = 'N' and a.PATIENT_FILE_ACTIVE_YN = 'Y' and (PATIENT_DISCHARGE_DATE is null or PATIENT_DISCHARGE_DATE = '') " +     
                                       " AND file_operator_to_userid IS NOT NULL " +        
                                         " AND b.patient_id = a.patient_id " +        
                                         " AND b.note_id = (SELECT MAX (note_id) " +        
                                                            " FROM aims_notes " +        
                                                           " WHERE aims_notes.patient_id = a.patient_id) " +        
                                         " AND c.guarantor_id = a.guarantor_id " +        
                                         " AND d.user_name = file_operator_to_userid " +
                                         " and datediff (D, CONVERT (smalldatetime, b.notes_dttm, 103), getdate()) > " + CaseLastCommentSLA  + " " +
                                    " ORDER BY file_operator_to_userid, " +
                                             " CAST (substring (a.patient_file_no, 1, 2) AS NUMERIC)";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Co-Ordinator</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Guarantor</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Last Updated Date Time</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>SLA Violation(days)</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        caseManager = dtDrillReportData.Rows[i]["file_allocated_to"].ToString();
                        PatientFile = dtDrillReportData.Rows[i]["patient_file_no"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        Guarantor = dtDrillReportData.Rows[i]["guarantor_name"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["patient_admission_date"].ToString();
                        NotesDTTM = dtDrillReportData.Rows[i]["notes_dttm"].ToString();
                        CommentSLAViolation = dtDrillReportData.Rows[i]["COMMENT_SLA"].ToString();

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + caseManager + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFile + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Guarantor + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + NotesDTTM + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + CommentSLAViolation + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=7><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=7><b>ALL FILES ARE UPDATED</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages("Patient Files Without Updated Notes/Comment in 2+ Days", "Email Successful", false);
                }
                else
                {
                    LogMessages("Patient Files Without Updated Notes/Comment in 2+ Days", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Patients Admitted NOT discharged after 14 Days", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesWithoutMedicalCommentsinLast24Hours()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string AdmissionDate = "";
            string PatientName = "";
            string Guarantor = "";
            string caseManager ="";
            string PatientFile ="";
            string NotesDTTM ="";
            string CommentSLAViolation = "";

            string DrillReportEmailSubject = "Patient Files Without Medical Update Notes/Comments in " + System.Convert.ToInt64(CaseLastCommentSLA)*24 + " Hours";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=7>" +
                                "<center><font color=5CACEE face=calibri size=4><b>" + DrillReportEmailSubject  + "</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=7>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT   d.user_full_name file_allocated_to, a.patient_file_no, " +        
                                             " dbo.INITCAP (a.patient_last_name + ' ' + a.patient_first_name " +        
                                                         " ) patient_name, " +        
                                             " c.guarantor_name, a.patient_admission_date, " +    
                                             " RTRIM (LTRIM (b.notes)) last_note_captured, b.notes_dttm, " +
                                             " datediff (D, CONVERT (smalldatetime, b.notes_dttm, 103), getdate()) COMMENT_SLA, PATIENT_DISCHARGE_DATE " +         
                                        " FROM aims_patient a, aims_notes b, aims_guarantor c, aims_users d " +        
                                       " WHERE " +
                                       " CANCELLED = 'N' and a.PATIENT_FILE_ACTIVE_YN = 'Y'  " +
                                      " and (PATIENT_DISCHARGE_DATE is null or PATIENT_DISCHARGE_DATE = '') " +
                                        " AND (patient_admission_date is not null or patient_admission_date != '') " +
                                        " AND CONVERT (smalldatetime, patient_admission_date, 103) < GETDATE() " +
                                        " and (a.IN_PATIENT = 'Y' or a.OUT_PATIENT = 'Y') " +
                                       " AND file_operator_to_userid IS NOT NULL " +
                                         " AND b.patient_id = a.patient_id AND b.NOTE_TYPE_ID = 8 " +        
                                         " AND b.note_id = (SELECT MAX (note_id) " +        
                                                            " FROM aims_notes " +        
                                                           " WHERE aims_notes.patient_id = a.patient_id) " +
                                         //" AND (b.NOTE_TYPE_ID = 8 or (SELECT COUNT(*) FROM AIMS_NOTES e WHERE e.PATIENT_ID = a.PATIENT_ID and e.NOTE_TYPE_ID=8) = 0) " +
                                         " AND c.guarantor_id = a.guarantor_id " +        
                                         " AND d.user_name = file_operator_to_userid " +
                                         " and datediff (D, CONVERT (smalldatetime, b.notes_dttm, 103), getdate()) > " + CaseLastCommentSLA  + " " +
                                    " ORDER BY file_operator_to_userid, " +
                                             " CAST (substring (a.patient_file_no, 1, 2) AS NUMERIC)";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Co-Ordinator</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Patient Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Guarantor</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Admission Date</b></td>" +
                               //"<td bgcolor=lightgrey valign=bottom align=center><b>Discharge Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>Last Updated Date Time</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center><b>SLA Violation(days)</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        caseManager = dtDrillReportData.Rows[i]["file_allocated_to"].ToString();
                        PatientFile = dtDrillReportData.Rows[i]["patient_file_no"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        Guarantor = dtDrillReportData.Rows[i]["guarantor_name"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["patient_admission_date"].ToString();
                        //DischargeDate = dtDrillReportData.Rows[i]["patient_discharge_date"].ToString();
                        NotesDTTM = dtDrillReportData.Rows[i]["notes_dttm"].ToString();
                        CommentSLAViolation = dtDrillReportData.Rows[i]["COMMENT_SLA"].ToString();

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + caseManager + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFile + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Guarantor + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        //"<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + DischargeDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + NotesDTTM + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + CommentSLAViolation + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=7><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=7><b>ALL FILES ARE UPDATED</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "jo-ann@aims.org.za; HendrikJ@aims.org.za");
                if (blResult)
                {
                    LogMessages("Patient Files Without Medical Update Notes/Comments in " + CaseLastCommentSLA + "+ Days", "Email Successful", false);
                }
                else
                {
                    LogMessages("Patient Files Without Medical Update Notes/Comments in " + CaseLastCommentSLA + "+ Days", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Patient Files Without Medical Update Notes/Comments in " + CaseLastCommentSLA + "+ Days", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesTaggedToOperatorsWithoutMedicalComments()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string AdmissionDate = "";
            string PatientName = "";
            
            string MedicalOfficer ="";
            
            string LastNoteCaptured = "";
            string NotesDateTime = "";
            string GuarantorName = "";
            

            string DrillReportEmailSubject = "Patient Case Without Medical Comments/Notes - Last " + System.Convert.ToInt64(CaseLastCommentSLA)*24 + " Hours";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table  cellpadding=1 cellspacing=1 border=1 bordercolor=black width=100% align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=9>" +
                                "<center><font color=5CACEE face=calibri size=4><b>" + DrillReportEmailSubject  + "</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=9>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT  f.User_Full_Name Medical_Officer,  "+
                                //d.user_full_name file_allocated_to, "+ 
                            " a.patient_file_no," +
                            " dbo.INITCAP (a.patient_last_name + ' ' + a.patient_first_name) patient_name," +
                         " c.guarantor_name, a.patient_admission_date," +
                         " RTRIM (LTRIM (b.notes)) last_note_captured, b.notes_dttm," +
                         " datediff (d,CONVERT (smalldatetime, b.notes_dttm, 103),getdate ()) comment_sla, " +
                        " b.USER_NAME, patient_discharge_date" +
                    " FROM aims_patient a, aims_notes b, aims_guarantor c,  "+
                    //aims_users d, 
                    " AIMS_USERS f " +
                   " WHERE cancelled = 'N'" +
                     " AND a.patient_file_active_yn = 'Y'" +
                     " AND (patient_discharge_date IS NULL OR patient_discharge_date = '') " +
                     " AND (patient_admission_date IS NOT NULL OR patient_admission_date != '') " +
                     " AND CONVERT (smalldatetime, patient_admission_date, 103) < getdate () " +
                     " AND (a.in_patient = 'Y' OR a.out_patient = 'Y') " +
                     //" AND file_operator_to_userid IS NOT NULL " +
                     " AND b.patient_id = a.patient_id " +
                     " AND b.note_id = " +
                            " (SELECT MAX (note_id) " +
                               " FROM aims_notes " +
                              " WHERE     aims_notes.patient_id = a.patient_id " +
                                    " AND aims_notes.note_type_id = 8 " +
                                 " OR (SELECT COUNT (*) " +
                                 " FROM aims_notes e " +
                                      " WHERE e.patient_id = a.patient_id AND e.note_type_id = 8) = 0) " +
                     " AND c.guarantor_id = a.guarantor_id " +
                     //" AND d.user_name = file_operator_to_userid " +
                     " AND datediff (d, CONVERT (smalldatetime, b.notes_dttm, 103), getdate ()) > " + CaseLastCommentSLA + " " +
	                " and f.User_Name = b.USER_NAME " +
                " ORDER BY f.User_Full_Name, " +
                         " CAST (substring (a.patient_file_no, 1, 2) AS NUMERIC) ";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               //"<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Co-Ordinator</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Medical Officer</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Patient Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Guarantor</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Admission Date</b></td>" +
                                //"<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Discharge Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Last Note/Comment Captured</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center nowrap><b>Note/Comment Date Time</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        //FileAllocatedTo = dtDrillReportData.Rows[i]["FILE_ALLOCATED_TO"].ToString();
                        MedicalOfficer = dtDrillReportData.Rows[i]["Medical_Officer"].ToString();
                        PatientFileNo = dtDrillReportData.Rows[i]["PATIENT_FILE_NO"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["PATIENT_NAME"].ToString();
                        GuarantorName = dtDrillReportData.Rows[i]["GUARANTOR_NAME"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["PATIENT_ADMISSION_DATE"].ToString();
                        //DischargeDate = dtDrillReportData.Rows[i]["PATIENT_DISCHARGE_DATE"].ToString();
                        LastNoteCaptured = dtDrillReportData.Rows[i]["LAST_NOTE_CAPTURED"].ToString();
                        NotesDateTime = dtDrillReportData.Rows[i]["NOTES_DTTM"].ToString();

                        //if (DischargeDate == "") { DischargeDate = "<font color=white>-</font>"; }
                        if (LastNoteCaptured == "") { LastNoteCaptured = "<font color=white>-</font>"; }
                        if (AdmissionDate == "") { AdmissionDate = "<font color=white>-</font>"; }
                        if (PatientName == "") { PatientName = "<font color=white>-</font>"; }

                        sEmailBody += "<tr style=border-style:thick>" +
                        //"<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + FileAllocatedTo + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + MedicalOfficer + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + PatientFileNo + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + PatientName + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + GuarantorName + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + AdmissionDate + "</td>" +
                            //"<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + DischargeDate + "</td>" +
                        "<td valign=top bgcolor=#ffffff align=center><b>" + LastNoteCaptured.Replace("\r\n","<br>") + "</b></td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center nowrap>" + NotesDateTime + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=9><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=9><b>" + DrillReportEmailSubject + " :Records Up-to-date</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za;jo-ann@aims.org.za;HendrikJ@aims.org.za");
                if (blResult)
                {
                    LogMessages(DrillReportEmailSubject + " - Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages(DrillReportEmailSubject + " - Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Patients Admitted NOT discharged after 14 Days", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesNotTaggedToOperators()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string AdmissionDate = "";
            string GuarantorName = "";
            string PatientName = "";

            string LateLogDTTm = "";
            string LateLogYN = "";
            string InOutPatient = "";

            string DrillReportEmailSubject = "Patient Case(s) Not Allocated To a Co-Ordinator";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=7>" +
                                "<center><font color=5CACEE face=calibri size=4><b>" + DrillReportEmailSubject + "</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=7>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT a.patient_id, a.patient_file_no, a.patient_admission_date, " +
                            " LTRIM (  dbo.INITCAP (e.title_desc)+ ' '+  " +
                            " dbo.INITCAP (patient_first_name) + ' '+ dbo.INITCAP (patient_last_name)) patient_name, " +
                            " B.GUARANTOR_NAME, " +
                            " a.late_log_yn, a.late_log_date, a.out_patient, a.in_patient " +
                            " FROM aims_patient a, aims_title e, aims_guarantor b " +
                            " WHERE a.cancelled = 'N' " +
                            " AND (a.pending = 'N' OR a.pending IS NULL) " +
                            " AND (a.patient_admission_date IS NOT NULL OR patient_admission_date <> '') " +
                            " AND (a.patient_discharge_date IS NULL OR a.patient_discharge_date = '') " +
                            " and (a.file_operator_to_userid is null or a.file_operator_to_userid ='') " +
                            " AND e.title_id = a.title_id " +
                            " and b.GUARANTOR_ID = a.GUARANTOR_ID " +
                            " ORDER BY 1 desc";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=5%><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=25%><b>Patient Full Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=30%><b>Guarantor</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=5%><b>Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=10%><b>Late Log(Y/N)</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=5%><b>Late Log Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=10%><b>Patient Status</b></td>" +
                                "</tr>"; 

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["PATIENT_FILE_NO"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["PATIENT_ADMISSION_DATE"].ToString();
                        GuarantorName = dtDrillReportData.Rows[i]["GUARANTOR_NAME"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        LateLogYN = dtDrillReportData.Rows[i]["LATE_LOG_YN"].ToString();
                        LateLogDTTm = dtDrillReportData.Rows[i]["LATE_LOG_DATE"].ToString();
                        InOutPatient = dtDrillReportData.Rows[i]["OUT_PATIENT"].ToString();

                        if (!LateLogDTTm.Equals(""))
                        {
                            LateLogDTTm = System.Convert.ToDateTime(LateLogDTTm).ToShortDateString();
                        }
                        if (InOutPatient.Equals("Y"))
                        {
                            InOutPatient = "<b>OUT-Patient</b>";
                        }
                        else
                        {
                            InOutPatient = "<b>IN-Patient</b>";
                        }

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + GuarantorName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + LateLogYN + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + LateLogDTTm + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + InOutPatient + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=7><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";

                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=7><b>All Patient Cases Allocated.</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages(DrillReportEmailSubject+  " Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages(DrillReportEmailSubject + " Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Patients Admitted NOT discharged after 14 Days", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateFilesWithoutCommentsinLast24HoursPerGuarantor()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();
            string AdmissionDate = "";
            string PatientName = "";
            string Guarantor = "";
            string LastGuarantor = "";
            string FileCoOrdinator = "";
            string PatientFile = "";
            string NotesDTTM = "";
            string sEmailColumnHeaders = "";
            bool bFirstTime = false;

            //string DrillReportEmailSubject = "Patient Files(Per Guarantor) Without Updated Notes/Comment in " + System.Convert.ToInt64(CaseLastCommentSLA) * 24 + " Hours";
            string DrillReportEmailSubject = "Active Patient Files(Per Guarantor) Not Discharged";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 border=1 style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=5>" +
                                "<center><font color=5CACEE face=calibri size=4><b>" + DrillReportEmailSubject + "</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=5>&nbsp;</td>" +
                                "</tr>";

                                //SQLString = " SELECT   c.guarantor_name,  " +
                                //                 " CAST (substring (a.patient_file_no, 4, 5) AS NUMERIC), " +
                                //                 " a.patient_file_no, " +
                                //                 " dbo.INITCAP (a.patient_last_name + ' ' + a.patient_first_name ) patient_name, " +
                                //                 " c.guarantor_name, a.patient_admission_date, " +
                                //                 " RTRIM (LTRIM (b.notes)) last_note_captured, b.notes_dttm, " +
                                //                 " datediff (d, CONVERT (smalldatetime, b.notes_dttm, 103), getdate () ) comment_sla, " +
                                //                 " d.User_Full_Name " +
                                //            " FROM aims_patient a, aims_notes b, aims_guarantor c , AIMS_USERS d " +
                                //           " WHERE cancelled = 'N' " +
                                //             " AND a.patient_file_active_yn = 'Y' " +
                                //             " AND (patient_discharge_date IS NULL OR patient_discharge_date = '') " +
                                //             " AND b.patient_id = a.patient_id " +
                                //             " AND b.note_id = (SELECT MAX (note_id) FROM aims_notes WHERE aims_notes.patient_id = a.patient_id) " +
                                //             " AND c.guarantor_id = a.guarantor_id " +
                                //             " AND datediff (d, CONVERT (smalldatetime, b.notes_dttm, 103), getdate ()) > " + CaseLastCommentSLA +
                                //             " and d.User_Name =+ a.FILE_OPERATOR_TO_USERID " +
                                //        " ORDER BY 1, CAST (substring (a.patient_file_no, 1, 2) AS NUMERIC) ";

                         //   SQLString = " SELECT   c.guarantor_name,    " +
                         //         " CAST (substring (a.patient_file_no, 4, 5) AS NUMERIC),   " +
                         //         " a.patient_file_no,   " +
                         //         " dbo.INITCAP (a.patient_last_name + ' ' + a.patient_first_name ) patient_name,   " +
                         //         " c.guarantor_name, a.patient_admission_date,   " +
                         //         " RTRIM (LTRIM (b.notes)) last_note_captured, b.notes_dttm,   " +
                         //         " datediff (d, CONVERT (smalldatetime, b.notes_dttm, 103), getdate () ) comment_sla ,  " +
                         //         " d.User_Full_Name,  " +
                         //         " b.NOTES  " +                                
                         //    " FROM aims_patient a  " +
                         //    " inner join aims_notes b on b.patient_id = a.patient_id  " + 
                         //    " inner join aims_guarantor c on c.guarantor_id = a.guarantor_id  " + 
                         //    " left outer join  AIMS_USERS d on d.User_Name = a.FILE_OPERATOR_TO_USERID  " +
                         //   " WHERE cancelled = 'N'  " + 
                         //     " AND a.patient_file_active_yn = 'Y'  " + 
                         //     " AND (patient_discharge_date IS NULL OR patient_discharge_date = '')  " + 
                         //     " AND b.note_id = (SELECT MAX (note_id) FROM aims_notes WHERE aims_notes.patient_id = a.patient_id)  " + 
                         //     " AND datediff (d, CONVERT (smalldatetime, b.notes_dttm, 103), getdate ()) >"  + CaseLastCommentSLA +
                         //" ORDER BY 1, CAST (substring (a.patient_file_no, 1, 2) AS NUMERIC)  ";


                SQLString = " SELECT   c.guarantor_name,  " +
                            " CAST (substring (a.patient_file_no, 4, 5) AS NUMERIC),  " +
                            " a.patient_file_no,  " +
                            " dbo.INITCAP (a.patient_last_name + ' ' + a.patient_first_name) patient_name,  " +
                            " c.guarantor_name, a.patient_admission_date,  " +
                            " c.guarantor_name, a.patient_admission_date,  " +
                            " d.user_full_name  " +
                            " FROM aims_patient a  " +
                            " INNER JOIN aims_guarantor c ON c.guarantor_id = a.guarantor_id  " +
                            " LEFT OUTER JOIN aims_users d ON d.user_name =  a.file_operator_to_userid  " +
                            " WHERE cancelled = 'N'  " +
                            " AND a.patient_file_active_yn = 'Y' AND a.pending = 'N' " +
                            " AND (patient_discharge_date IS NULL OR patient_discharge_date = '')  " +
                            " and PATIENT_ADMISSION_DATE is not null and CONVERT (smalldatetime, PATIENT_ADMISSION_DATE, 103) < GETDATE() "+
                            " AND (c.GUARANTOR_NAME != '' or c.GUARANTOR_NAME != ' ')  " +
                            " ORDER BY 1, CAST (substring (a.patient_file_no, 1, 2) AS NUMERIC) ";


                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailColumnHeaders += "<tr>" +
                               "<td nowrap bgcolor=lightgrey valign=bottom align=center width=10%><b>Co-Ordinator</b></td>" +
                               "<td nowrap bgcolor=lightgrey valign=bottom align=center width=10%><b>Patient File No</b></td>" +
                               "<td nowrap bgcolor=lightgrey valign=bottom align=center width=35%><b>Patient Name</b></td>" +
                               "<td nowrap bgcolor=lightgrey valign=bottom align=center width=30%><b>Guarantor</b></td>" +
                               "<td nowrap bgcolor=lightgrey valign=bottom align=center width=15%><b>Admission Date</b></td>" +
                               //"<td nowrap bgcolor=lightgrey valign=bottom align=center width=10%><b>Last Updated Date Time</b></td>" +
                               //"<td nowrap bgcolor=lightgrey valign=bottom align=center width=50%><b>Last Note/Comment Captured</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        FileCoOrdinator = dtDrillReportData.Rows[i]["User_Full_Name"].ToString();
                        if (FileCoOrdinator.Equals(""))
                        {
                            FileCoOrdinator = "-";
                        }
                        Guarantor = dtDrillReportData.Rows[i]["guarantor_name"].ToString();
                        PatientFile = dtDrillReportData.Rows[i]["patient_file_no"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        Guarantor = dtDrillReportData.Rows[i]["guarantor_name"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["patient_admission_date"].ToString();
                        //NotesDTTM = dtDrillReportData.Rows[i]["notes_dttm"].ToString();
                        //LastNoteCaptured = dtDrillReportData.Rows[i]["last_note_captured"].ToString();

                        if (!LastGuarantor.Equals(Guarantor))
                        {
                            LastGuarantor = Guarantor;
                            if (bFirstTime)
                            {
                                sEmailBody += "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=5>&nbsp;</td>" +
                                "</tr>";
                            }
                            bFirstTime = true;
                            sEmailBody += "<tr><td colspan=5 bgcolor=lightgrey><b>" + Guarantor + "</b></td></tr>";
                            sEmailBody += sEmailColumnHeaders;
                        }

                        if (AdmissionDate.Trim().Equals(""))
                        {
                            AdmissionDate = "&nbsp;";
                        }
                        sEmailBody += "<tr  style=border-style:thick>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + FileCoOrdinator + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFile + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + Guarantor + "</td>" +
                        "<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        //"<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + NotesDTTM + "</td>" +
                        //"<td valign=top bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=left>" + LastNoteCaptured.Replace("\r\n", "<br>") + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><b>ALL FILES ARE UPDATED</b></td>" +
                                "</tr>";
                }

                sEmailBody += "<tr>" +
                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=5>&nbsp;</td>" +
                "</tr>";

                sEmailBody += "</table>" +
                 "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                
                if (blResult)
                {
                    LogMessages("Patient Files Without Updated Notes/Comment in 2+ Days", "Email Successful", false);
                }
                else
                {
                    LogMessages("Patient Files Without Updated Notes/Comment in 2+ Days", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Patient Files Without Updated Notes/Comment", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateAfterHoursFiles()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string PatientFileNo = "";
            string AdmissionDate = "";
            string GuarantorName = "";
            string PatientName = "";
            
            string LateLogDTTm = "";
            
            string InOutPatient = "";

            string DrillReportEmailSubject = "After-Hours Files Not Allocated";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=5>" +
                                "<center><font color=5CACEE face=calibri size=4><b>" + DrillReportEmailSubject + "</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=5>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT   a.patient_id, a.patient_file_no, a.patient_admission_date, " +
                            " LTRIM (  dbo.INITCAP (e.title_desc) "+
                            " + ' ' "+
                            " + dbo.INITCAP (patient_first_name) "+
                            " + ' ' "+
                            " + dbo.INITCAP (patient_last_name) "+
                            " ) patient_name, "+
                            " b.guarantor_name, a.out_patient, a.in_patient "+
                            " FROM aims_patient a, aims_title e, aims_guarantor b "+
                            " WHERE a.cancelled = 'N' "+
                            " AND a.after_hours_file = 'Y' "+
                            " AND (a.FILE_OPERATOR_TO_USERID = '' OR a.FILE_OPERATOR_TO_USERID IS NULL " +
                            " ) "+
                            " AND e.title_id = a.title_id "+
                            " AND b.guarantor_id = a.guarantor_id "+
                            " ORDER BY 1 DESC";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=10%><b>Patient File No</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=30%><b>Patient Full Name</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=40%><b>Guarantor</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=10%><b>Admission Date</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=10%><b>Patient Status</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {
                        PatientFileNo = dtDrillReportData.Rows[i]["PATIENT_FILE_NO"].ToString();
                        AdmissionDate = dtDrillReportData.Rows[i]["PATIENT_ADMISSION_DATE"].ToString();
                        GuarantorName = dtDrillReportData.Rows[i]["GUARANTOR_NAME"].ToString();
                        PatientName = dtDrillReportData.Rows[i]["patient_name"].ToString();
                        InOutPatient = dtDrillReportData.Rows[i]["OUT_PATIENT"].ToString();

                        if (!LateLogDTTm.Equals(""))
                        {
                            LateLogDTTm = System.Convert.ToDateTime(LateLogDTTm).ToShortDateString();
                        }
                        if (InOutPatient.Equals("Y"))
                        {
                            InOutPatient = "<b>OUT-Patient</b>";
                        }
                        else
                        {
                            InOutPatient = "<b>IN-Patient</b>";
                        }

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientFileNo + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + PatientName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + GuarantorName + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + AdmissionDate + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + InOutPatient + "</td>" +
                        "</tr>";
                    }
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><font color=red><b>TOTAL - " + dtDrillReportData.Rows.Count + "</b></font></td>" +
                                "</tr>";

                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=5><b>No After-Hours Files Found</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages(DrillReportEmailSubject + " Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages(DrillReportEmailSubject + " Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Patients Admitted NOT discharged after 14 Days", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateWorkBaskets()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string DrillReportEmailSubject = "Co-Ordinator Work Basket SLA Report - Emails not processed";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=2>" +
                                "<center><font color=5CACEE face=calibri size=4><b>" + DrillReportEmailSubject + "</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=2>&nbsp;</td>" +
                                "</tr>";

                SQLString = "select c.user_full_name, " +
                        " COUNT(c.User_Name) ITEMS from AIMS_EWS_OPERATOR_MAILS a, " +
                        " AIMS_EWS_OPERATOR_MAILBOX b, AIMS_USERS c " +
                         " where WORK_ITEM_PROCESSED_YN = 'N' " +
                         " and b.OPERATOR_MAILBOX_ID = a.OPERATOR_MAILBOX_ID " +
                         " and c.User_Name = b.OPERATOR_MAILBOX_USER_NAME " +
                         " group by c.user_full_name " +
                         " order by 2";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=80%><b>Co-Ordinator</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=20%><b>Work Basket Items</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + dtDrillReportData.Rows[i]["user_full_name"].ToString() + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + dtDrillReportData.Rows[i]["ITEMS"].ToString() + "</td>" +
                        "</tr>";
                    }
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=2><b>Not after-hours files found</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "eric@aims.org.za; juan-dreb@aims.org.za;stanleyn@aims.org.za");
                if (blResult)
                {
                    LogMessages(DrillReportEmailSubject + " Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages(DrillReportEmailSubject + " Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Patients Admitted NOT discharged after 14 Days", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        public void GenerateAdminProductivity()
        {
            AIMSEmailer.AIMS.Utility.eMailer aimsEmailer = new AIMSEmailer.AIMS.Utility.eMailer();

            string SQLString = "";
            string sEmailBody = "";
            bool blResult = false;
            OleDbCommand cmdDrillReport = new OleDbCommand();
            OleDbDataAdapter oleDrillDBAdaptor;
            DataTable dtDrillReportData = new DataTable();

            string DrillReportEmailSubject = "Admin Team Productivity - Weekly [" + DateTime.Now.AddDays(-1).ToShortDateString() + "]";

            try
            {
                sEmailBody = "<html> " +
                                "<head>" +
                                "<style>TABLE{FONT-SIZE: 8pt;COLOR: #666666;LINE-HEIGHT: 9pt;FONT-FAMILY: Verdana, Arial;HEIGHT: 1pt;TEXT-ALIGN: left}</style>" +
                                "</head>" +
                                "<body>" +
                                "<br>" +
                                "<br>" +
                                "<table width=100% cellpadding=2 cellspacing=1 align=center style=border-style:solid>" +
                                "<tr>" +
                                "<td bgcolor=lightgrey align=right colspan=2>" +
                                "<center><font color=5CACEE face=calibri size=4><b>" + DrillReportEmailSubject + "</b></font></center>" +
                                "</td>" +
                                "</tr>" +
                                "<tr>" +
                                "<td bgcolor=#ffffff width=100% style=TEXT-TRANSFORM: capitalize colspan=2>&nbsp;</td>" +
                                "</tr>";

                SQLString = "SELECT b.USER_FULL_NAME, COUNT (a.modified_user) ITEMS" +
                            " FROM aims_a_invoice a, aims_users b "+
                            " WHERE CONVERT (datetime, a.modified_date, 103) >= GETDATE() - 8 "+
                            " AND a.modified_user IN (SELECT user_name "+
                            " FROM aims_user_role "+
                            " WHERE role_cd = 'Admin') and b.user_name = a.modified_user " +
                            " GROUP BY b.USER_FULL_NAME " +
                            " HAVING COUNT (a.modified_user) > 0 " +
                            " ORDER BY 2";

                cmdDrillReport.Connection = oleDBConnection;
                cmdDrillReport.CommandText = SQLString;
                cmdDrillReport.CommandType = CommandType.Text;
                oleDrillDBAdaptor = new OleDbDataAdapter(cmdDrillReport);
                oleDrillDBAdaptor.Fill(dtDrillReportData);

                if (dtDrillReportData.Rows.Count > 0)
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=80%><b>Administrator</b></td>" +
                               "<td bgcolor=lightgrey valign=bottom align=center width=20%><b>Work Effort</b></td>" +
                                "</tr>";

                    for (int i = 0; i < dtDrillReportData.Rows.Count; i++)
                    {

                        sEmailBody += "<tr>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + dtDrillReportData.Rows[i]["USER_FULL_NAME"].ToString() + "</td>" +
                        "<td valign=bottom bgcolor=#ffffff style=TEXT-TRANSFORM: capitalize align=center>" + dtDrillReportData.Rows[i]["ITEMS"].ToString() + "</td>" +
                        "</tr>";
                    }
                }
                else
                {
                    sEmailBody += "<tr>" +
                               "<td bgcolor=lightgrey valign=bottom align=center colspan=2><b>Not Records for Administrators Productivity</b></td>" +
                                "</tr>";
                }
                sEmailBody += "</table>" +
                "<br>" +
                "<br>" +
                "</body>" +
                "</html>";

                blResult = aimsEmailer.SendEmailNotify(sEmailBody, DrillReportEmailSubject, "debbie@aims.org.za");
                if (blResult)
                {
                    LogMessages(DrillReportEmailSubject + " Report Email sent successfully", "Email Successful", false);
                }
                else
                {
                    LogMessages(DrillReportEmailSubject + " Report Email NOT sent successfully", "Email UnSuccessful", false);
                }
            }
            catch (System.Exception ex)
            {
                blResult = false;
                LogMessages(ex.ToString(), "Generating Admin Productivity Report", true);
            }
            finally
            {
                cmdDrillReport.Dispose();
                dtDrillReportData.Dispose();
                aimsEmailer = null;
            }
        }

        #endregion
    }
}